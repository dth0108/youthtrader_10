import { Progress } from "@/components/ui/progress";

interface SurveyHeaderProps {
  currentStep: number;
  totalSteps: number;
}

export function SurveyHeader({ currentStep, totalSteps }: SurveyHeaderProps) {
  const progressPercent = (currentStep / totalSteps) * 100;
  
  const steps = [
    { emoji: "🏝️", text: "위치", color: "text-emerald-600" },
    { emoji: "🍽️", text: "음식&음료", color: "text-teal-600" },
    { emoji: "🕐", text: "시간", color: "text-cyan-600" },
    { emoji: "🎉", text: "완료", color: "text-amber-600" }
  ];

  const getStepMessage = () => {
    switch (currentStep) {
      case 1: return "어디서 만날까요? 🏝️";
      case 2: return "무엇을 먹고 마실까요? 🍽️";
      case 3: return "모임 시간은 언제가 좋아요? 🕐";
      default: return "힐링 설문 완료! 🌿";
    }
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50 border-b-4 border-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full flex items-center justify-center bounce-in">
              <span className="text-white text-2xl pulse-emoji">🌿</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-emerald-800">청년무역 인턴 동기 모임</h1>
              <p className="text-sm text-teal-600 font-medium">2025년 7월 22일 힐링 모임 설문 🌿</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500 font-medium">진행률</p>
            <p className="text-2xl font-bold bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text text-transparent">
              {currentStep}/{totalSteps}
            </p>
          </div>
        </div>
        
        <div className="text-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800 bounce-in">
            {getStepMessage()}
          </h2>
        </div>
        
        <div className="mt-4">
          <div className="flex justify-between text-sm mb-3">
            {steps.map((step, index) => (
              <div 
                key={index} 
                className={`text-center transition-all duration-300 ${
                  currentStep > index 
                    ? `${step.color} font-bold transform scale-110` 
                    : "text-gray-400"
                }`}
              >
                <div className={`text-lg ${currentStep > index ? 'pulse-emoji' : ''}`}>
                  {step.emoji}
                </div>
                <span className="text-xs">{step.text}</span>
              </div>
            ))}
          </div>
          <div className="relative">
            <Progress value={progressPercent} className="h-3 bg-gray-200" />
            <div 
              className="absolute top-0 left-0 h-3 rainbow-progress rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>
    </header>
  );
}
