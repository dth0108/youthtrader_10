import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ANIMAL_AVATARS } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface UserIdentityStepProps {
  selectedAnimal: { emoji: string; nickname: string } | null;
  onAnimalSelect: (animal: { emoji: string; nickname: string }) => void;
  onNext: () => void;
}

export function UserIdentityStep({ 
  selectedAnimal, 
  onAnimalSelect, 
  onNext
}: UserIdentityStepProps) {
  const [shake, setShake] = useState(false);
  
  // Fetch used nicknames to disable them
  const { data: usedData } = useQuery({
    queryKey: ["/api/survey/used-nicknames"],
    refetchInterval: 2000, // Refresh every 2 seconds for real-time updates
  });
  
  const usedNicknames = usedData?.usedNicknames || [];

  const handleNext = () => {
    if (!selectedAnimal) {
      setShake(true);
      setTimeout(() => setShake(false), 500);
      return;
    }
    onNext();
  };

  const isAnimalUsed = (nickname: string) => {
    return usedNicknames.includes(nickname);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8 p-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-white mb-2">
          <span className="pulse-emoji text-5xl">🌿</span>
          <br />
          자연 친구를 선택하세요!
        </h1>
        <p className="text-xl text-emerald-100">
          7월 22일 청년무역인턴 힐링 모임 설문조사
        </p>
        <p className="text-lg text-teal-100">
          각 캐릭터는 한 명만 선택할 수 있어요 ✨
        </p>
      </div>

      {/* Animal Character Selection */}
      <Card className={`bg-white/20 backdrop-blur-sm border-white/30 transition-all duration-300 ${shake ? 'shake' : ''}`}>
        <CardContent className="p-6 space-y-6">
          <h2 className="text-white text-xl font-bold text-center">
            🐾 동물 친구들 🐾
          </h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {ANIMAL_AVATARS.map((animal) => {
              const isUsed = isAnimalUsed(animal.nickname);
              const isSelected = selectedAnimal?.nickname === animal.nickname;
              
              return (
                <button
                  key={animal.nickname}
                  onClick={() => !isUsed && onAnimalSelect(animal)}
                  disabled={isUsed}
                  className={`
                    relative p-4 rounded-xl transition-all duration-300 text-center
                    ${isSelected 
                      ? 'bg-yellow-400 scale-105 ring-4 ring-yellow-300 shadow-lg' 
                      : isUsed
                        ? 'bg-gray-500/50 opacity-50 cursor-not-allowed'
                        : 'bg-white/60 hover:bg-white/80 hover:scale-105 cursor-pointer'
                    }
                  `}
                >
                  <div className="text-3xl mb-2 relative">
                    {animal.emoji}
                    {isUsed && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-red-500 text-2xl">❌</span>
                      </div>
                    )}
                  </div>
                  <div className={`text-sm font-bold ${isUsed ? 'text-gray-400' : 'text-gray-800'}`}>
                    {animal.nickname}
                  </div>
                  <div className={`text-xs ${isUsed ? 'text-gray-500' : 'text-gray-600'}`}>
                    {animal.description}
                  </div>
                  {isUsed && (
                    <div className="text-xs text-red-400 mt-1 font-semibold">
                      선택됨
                    </div>
                  )}
                </button>
              );
            })}
          </div>
          
          <div className="text-center">
            <p className="text-white/70 text-sm">
              현재 {usedNicknames.length}명이 참여했습니다
            </p>
            <p className="text-white/60 text-xs">
              실시간으로 업데이트됩니다 🔄
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Selected Preview */}
      {selectedAnimal && (
        <Card className="bg-gradient-to-r from-yellow-400/20 to-orange-400/20 backdrop-blur-sm border-yellow-300/30 bounce-in">
          <CardContent className="p-6">
            <div className="flex items-center justify-center space-x-4">
              <span className="text-5xl pulse-emoji">{selectedAnimal.emoji}</span>
              <div className="text-center">
                <p className="text-white font-bold text-2xl">{selectedAnimal.nickname}</p>
                <p className="text-white/80 text-lg">으로 참여합니다!</p>
                <p className="text-yellow-200 text-sm mt-1">이제 설문을 시작할 수 있어요 🚀</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Next Button */}
      <div className="flex justify-center pt-4">
        <Button
          onClick={handleNext}
          disabled={!selectedAnimal}
          className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold text-lg px-8 py-3 rounded-xl 
                     shadow-lg transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {selectedAnimal ? (
            <>
              {selectedAnimal.emoji} {selectedAnimal.nickname}로 설문 시작!
              <span className="ml-2">🚀</span>
            </>
          ) : (
            <>
              캐릭터를 선택해주세요
              <span className="ml-2">👆</span>
            </>
          )}
        </Button>
      </div>
    </div>
  );
}