import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, ArrowLeft, Utensils } from "lucide-react";

interface FoodStepProps {
  selectedFoods: string[];
  onFoodToggle: (food: string) => void;
  onNext: () => void;
  onPrevious: () => void;
}

const foodTypes = [
  { 
    id: "korean", 
    name: "한식", 
    description: "삼겹살, 갈비, 김치찌개 등",
    emoji: "🥢",
    color: "from-red-400 to-red-600",
    bgColor: "bg-red-50",
    image: "https://images.unsplash.com/photo-1590301157890-4810ed352733?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
  },
  { 
    id: "chinese", 
    name: "중식", 
    description: "짜장면, 탕수육, 마라탕 등",
    emoji: "🥟",
    color: "from-yellow-400 to-orange-500",
    bgColor: "bg-yellow-50",
    image: "https://images.unsplash.com/photo-1617093727343-374698b1b08d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
  },
  { 
    id: "japanese", 
    name: "일식", 
    description: "초밥, 라멘, 이자카야 등",
    emoji: "🍣",
    color: "from-pink-400 to-pink-600",
    bgColor: "bg-pink-50",
    image: "https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
  },
  { 
    id: "western", 
    name: "양식", 
    description: "파스타, 스테이크, 피자 등",
    emoji: "🍝",
    color: "from-green-400 to-green-600",
    bgColor: "bg-green-50",
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
  },
  { 
    id: "bbq", 
    name: "고기구이", 
    description: "삼겹살, 갈비, 곱창 등",
    emoji: "🥩",
    color: "from-orange-400 to-red-500",
    bgColor: "bg-orange-50",
    image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
  },
  { 
    id: "other", 
    name: "기타", 
    description: "멕시칸, 인도, 태국 등",
    emoji: "🌮",
    color: "from-purple-400 to-purple-600",
    bgColor: "bg-purple-50",
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
  },
];

export function FoodStep({ selectedFoods, onFoodToggle, onNext, onPrevious }: FoodStepProps) {
  return (
    <div className="gradient-bg-food rounded-2xl shadow-lg p-8 mb-6 bounce-in">
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6 bounce-in">
          <span className="text-4xl pulse-emoji">😋</span>
        </div>
        <h2 className="text-3xl font-bold text-white mb-3">오늘은 어떤 맛? 😋</h2>
        <p className="text-lg text-white/90 font-medium">여러 개를 선택할 수 있어요! 맛있는 걸 골라보세요 ✨</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {foodTypes.map((food, index) => {
          const isSelected = selectedFoods.includes(food.id);
          return (
            <Card 
              key={food.id}
              className={`cursor-pointer fun-card relative overflow-hidden border-2 ${
                isSelected 
                  ? `border-white bg-gradient-to-br ${food.color} text-white shadow-2xl selected` 
                  : `border-white/30 bg-white/90 hover:border-white hover:bg-white`
              }`}
              onClick={() => onFoodToggle(food.id)}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6 relative">
                {isSelected && (
                  <div className="absolute top-2 right-2">
                    <span className="text-2xl pulse-emoji">✨</span>
                  </div>
                )}
                <div className="text-center">
                  <div 
                    className="h-24 bg-gray-100 rounded-xl mb-4 bg-cover bg-center relative overflow-hidden" 
                    style={{ backgroundImage: `url(${food.image})` }}
                  >
                    <div className="absolute inset-0 bg-black/20"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-4xl pulse-emoji drop-shadow-lg">{food.emoji}</span>
                    </div>
                  </div>
                  <h3 className={`text-xl font-bold mb-2 ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                    {food.name}
                  </h3>
                  <p className={`text-sm ${isSelected ? 'text-white/90' : 'text-gray-600'}`}>
                    {food.description}
                  </p>
                </div>
                {isSelected && (
                  <div className="absolute bottom-2 right-2">
                    <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                      <span className="text-green-500 text-lg">✓</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="flex justify-between items-center">
        <Button 
          onClick={onPrevious}
          variant="outline"
          className="px-6 py-3 bg-white/20 text-white border-white/30 hover:bg-white/30"
        >
          <ArrowLeft className="mr-2" size={16} /> 이전
        </Button>
        
        <div className="text-center">
          <p className="text-white/80 text-sm mb-2">
            {selectedFoods.length > 0 ? `${selectedFoods.length}개 선택됨` : '음식을 선택해주세요'}
          </p>
        </div>

        <Button 
          onClick={onNext}
          disabled={selectedFoods.length === 0}
          className={`px-8 py-3 text-lg font-semibold rounded-xl transition-all duration-300 ${
            selectedFoods.length > 0
              ? 'bg-white text-pink-600 hover:bg-gray-100 shadow-lg hover:shadow-xl transform hover:scale-105' 
              : 'bg-white/20 text-white/50 cursor-not-allowed'
          }`}
        >
          {selectedFoods.length > 0 ? '맛있겠다! 다음으로 🚀' : '음식을 골라주세요'}
          <ArrowRight className="ml-2" size={20} />
        </Button>
      </div>
    </div>
  );
}
