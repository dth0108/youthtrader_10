import { Progress } from "@/components/ui/progress";

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

export function ProgressBar({ currentStep, totalSteps }: ProgressBarProps) {
  const progressPercent = (currentStep / totalSteps) * 100;
  
  return (
    <div className="w-full">
      <div className="flex justify-between text-xs text-gray-500 mb-2">
        <span>위치</span>
        <span>음식</span>
        <span>주류</span>
        <span>시간</span>
        <span>결과</span>
      </div>
      <Progress value={progressPercent} className="h-2" />
    </div>
  );
}
