import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, ArrowLeft, Wine, Beer, Coffee } from "lucide-react";

interface DrinksStepProps {
  selectedDrinks: string[];
  onDrinkToggle: (drink: string) => void;
  onNext: () => void;
  onPrevious: () => void;
}

const drinkTypes = [
  { id: "beer", name: "맥주", description: "생맥주, 병맥주", icon: Beer, emoji: "🍺", color: "from-yellow-400 to-yellow-600", bgColor: "bg-yellow-50" },
  { id: "soju", name: "소주", description: "참이슬, 처음처럼 등", icon: Wine, emoji: "🍶", color: "from-blue-400 to-blue-600", bgColor: "bg-blue-50" },
  { id: "somaek", name: "소맥", description: "소주 + 맥주", icon: Wine, emoji: "🍻", color: "from-green-400 to-green-600", bgColor: "bg-green-50" },
  { id: "highball", name: "하이볼", description: "위스키 + 소다", icon: Wine, emoji: "🥃", color: "from-purple-400 to-purple-600", bgColor: "bg-purple-50" },
  { id: "wine", name: "와인", description: "레드, 화이트, 스파클링", icon: Wine, emoji: "🍷", color: "from-red-400 to-red-600", bgColor: "bg-red-50" },
  { id: "nonalcoholic", name: "무알코올", description: "음료수, 차, 커피", icon: Coffee, emoji: "🥤", color: "from-gray-400 to-gray-600", bgColor: "bg-gray-50" },
];

export function DrinksStep({ selectedDrinks, onDrinkToggle, onNext, onPrevious }: DrinksStepProps) {
  return (
    <div className="gradient-bg-drink rounded-2xl shadow-lg p-8 mb-6 bounce-in">
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6 bounce-in">
          <span className="text-4xl pulse-emoji">🍻</span>
        </div>
        <h2 className="text-3xl font-bold text-white mb-3">분위기를 더할 한 잔은? 🍻</h2>
        <p className="text-lg text-white/90 font-medium">어떤 음료로 건배할까요? 여러 개 선택 가능해요! ✨</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {drinkTypes.map((drink, index) => {
          const isSelected = selectedDrinks.includes(drink.id);
          return (
            <Card 
              key={drink.id}
              className={`cursor-pointer fun-card relative overflow-hidden border-2 ${
                isSelected 
                  ? `border-white bg-gradient-to-br ${drink.color} text-white shadow-2xl selected` 
                  : `border-white/30 bg-white/90 hover:border-white hover:bg-white`
              }`}
              onClick={() => onDrinkToggle(drink.id)}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6 relative">
                {isSelected && (
                  <div className="absolute top-2 right-2">
                    <span className="text-2xl pulse-emoji">✨</span>
                  </div>
                )}
                <div className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
                    isSelected ? 'bg-white/20' : 'bg-white'
                  }`}>
                    <span className="text-3xl pulse-emoji">{drink.emoji}</span>
                  </div>
                  <h3 className={`text-xl font-bold mb-2 ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                    {drink.name}
                  </h3>
                  <p className={`text-sm ${isSelected ? 'text-white/90' : 'text-gray-600'}`}>
                    {drink.description}
                  </p>
                </div>
                {isSelected && (
                  <div className="absolute bottom-2 right-2">
                    <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                      <span className="text-green-500 text-lg">✓</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="flex justify-between items-center">
        <Button 
          onClick={onPrevious}
          variant="outline"
          className="px-6 py-3 bg-white/20 text-white border-white/30 hover:bg-white/30"
        >
          <ArrowLeft className="mr-2" size={16} /> 이전
        </Button>
        
        <div className="text-center">
          <p className="text-white/80 text-sm mb-2">
            {selectedDrinks.length > 0 ? `${selectedDrinks.length}개 선택됨` : '음료를 선택해주세요'}
          </p>
        </div>

        <Button 
          onClick={onNext}
          disabled={selectedDrinks.length === 0}
          className={`px-8 py-3 text-lg font-semibold rounded-xl transition-all duration-300 ${
            selectedDrinks.length > 0
              ? 'bg-white text-cyan-600 hover:bg-gray-100 shadow-lg hover:shadow-xl transform hover:scale-105' 
              : 'bg-white/20 text-white/50 cursor-not-allowed'
          }`}
        >
          {selectedDrinks.length > 0 ? '좋은 선택! 다음으로 🚀' : '음료를 골라주세요'}
          <ArrowRight className="ml-2" size={20} />
        </Button>
      </div>
    </div>
  );
}
