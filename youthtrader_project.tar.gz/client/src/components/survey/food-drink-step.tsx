import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FOOD_TYPES, DRINK_TYPES } from "@shared/schema";

interface FoodDrinkStepProps {
  selectedFoods: string[];
  selectedDrinks: string[];
  onFoodToggle: (food: string) => void;
  onDrinkToggle: (drink: string) => void;
  onNext: () => void;
  onPrevious: () => void;
}

export function FoodDrinkStep({ 
  selectedFoods, 
  selectedDrinks, 
  onFoodToggle, 
  onDrinkToggle, 
  onNext, 
  onPrevious 
}: FoodDrinkStepProps) {
  const canProceed = selectedFoods.length > 0 && selectedDrinks.length > 0;

  return (
    <div className="animate-fade-in space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
          🍽️ 음식 & 음료 선택
        </h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          함께 나누고 싶은 음식과 음료를 선택해주세요
        </p>
      </div>

      {/* Food Selection */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-emerald-700 flex items-center gap-2">
          🥘 음식 종류
          <span className="text-sm text-muted-foreground font-normal">
            (선택: {selectedFoods.length}개)
          </span>
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {FOOD_TYPES.map((food) => {
            const isSelected = selectedFoods.includes(food.id);
            return (
              <Card
                key={food.id}
                className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                  isSelected 
                    ? "bg-gradient-to-br from-emerald-100 to-teal-100 border-emerald-400 shadow-emerald-200 shadow-lg" 
                    : "bg-white hover:bg-gradient-to-br hover:from-emerald-50 hover:to-teal-50 border-gray-200 hover:border-emerald-300"
                }`}
                onClick={() => onFoodToggle(food.id)}
              >
                <CardContent className="p-4 text-center">
                  <div className={`text-2xl mb-2 ${isSelected ? "animate-bounce-gentle" : ""}`}>
                    {food.id === 'korean' && '🍚'}
                    {food.id === 'chinese' && '🥟'}
                    {food.id === 'japanese' && '🍣'}
                    {food.id === 'western' && '🍝'}
                    {food.id === 'bbq' && '🥩'}
                    {food.id === 'other' && '🌮'}
                  </div>
                  <p className={`font-medium ${
                    isSelected ? "text-emerald-800" : "text-gray-800"
                  }`}>
                    {food.name}
                  </p>
                  <p className={`text-xs mt-1 ${
                    isSelected ? "text-emerald-600" : "text-gray-600"
                  }`}>
                    {food.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Drink Selection */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-teal-700 flex items-center gap-2">
          🥤 음료 종류
          <span className="text-sm text-muted-foreground font-normal">
            (선택: {selectedDrinks.length}개)
          </span>
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {DRINK_TYPES.map((drink) => {
            const isSelected = selectedDrinks.includes(drink.id);
            return (
              <Card
                key={drink.id}
                className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                  isSelected 
                    ? "bg-gradient-to-br from-blue-100 to-cyan-100 border-blue-400 shadow-blue-200 shadow-lg" 
                    : "bg-white hover:bg-gradient-to-br hover:from-blue-50 hover:to-cyan-50 border-gray-200 hover:border-blue-300"
                }`}
                onClick={() => onDrinkToggle(drink.id)}
              >
                <CardContent className="p-4 text-center">
                  <div className={`text-2xl mb-2 ${isSelected ? "animate-bounce-gentle" : ""}`}>
                    {drink.id === 'beer' && '🍺'}
                    {drink.id === 'soju' && '🍶'}
                    {drink.id === 'somaek' && '🍻'}
                    {drink.id === 'highball' && '🥃'}
                    {drink.id === 'wine' && '🍷'}
                    {drink.id === 'nonalcoholic' && '☕'}
                  </div>
                  <p className={`font-medium ${
                    isSelected ? "text-blue-800" : "text-gray-800"
                  }`}>
                    {drink.name}
                  </p>
                  <p className={`text-xs mt-1 ${
                    isSelected ? "text-blue-600" : "text-gray-600"
                  }`}>
                    {drink.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between pt-6">
        <Button 
          variant="outline" 
          onClick={onPrevious}
          className="px-8 border-stone-300 text-stone-600 hover:bg-stone-50"
        >
          ← 이전
        </Button>
        <Button 
          onClick={onNext} 
          disabled={!canProceed}
          className="px-8 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 disabled:opacity-50"
        >
          다음 → 
        </Button>
      </div>

      {!canProceed && (
        <p className="text-center text-amber-600 text-sm">
          🌿 음식과 음료를 각각 하나씩은 선택해주세요
        </p>
      )}
    </div>
  );
}