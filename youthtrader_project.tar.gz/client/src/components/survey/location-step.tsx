import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, MapPin, Building, Music, Landmark, ShoppingBag, GraduationCap, Car } from "lucide-react";

interface LocationStepProps {
  selectedLocation: string | null;
  onLocationSelect: (location: string) => void;
  onNext: () => void;
}

const locations = [
  { 
    id: "gangnam", 
    name: "강남", 
    description: "역삼/서초 일대", 
    icon: Building,
    emoji: "🏢",
    color: "from-emerald-400 to-emerald-600",
    bgColor: "bg-emerald-50"
  },
  { 
    id: "hongdae", 
    name: "홍대", 
    description: "홍익대 주변", 
    icon: Music,
    emoji: "🎵",
    color: "from-teal-400 to-teal-600",
    bgColor: "bg-teal-50"
  },
  { 
    id: "jongno", 
    name: "종로", 
    description: "종로3가 일대", 
    icon: Landmark,
    emoji: "🏛️",
    color: "from-amber-400 to-amber-600",
    bgColor: "bg-amber-50"
  },
  { 
    id: "myeongdong", 
    name: "명동", 
    description: "중구 명동", 
    icon: ShoppingBag,
    emoji: "🛍️",
    color: "from-purple-400 to-purple-600",
    bgColor: "bg-purple-50"
  },
  { 
    id: "hangang", 
    name: "한강", 
    description: "여의도/반포 한강공원", 
    icon: Car,
    emoji: "🌊",
    color: "from-cyan-400 to-cyan-600",
    bgColor: "bg-cyan-50"
  },
  { 
    id: "sinchon", 
    name: "신촌", 
    description: "연세대 주변", 
    icon: GraduationCap,
    emoji: "🎓",
    color: "from-green-400 to-green-600",
    bgColor: "bg-green-50"
  },
];

export function LocationStep({ selectedLocation, onLocationSelect, onNext }: LocationStepProps) {
  return (
    <div className="bg-gradient-to-br from-emerald-50 via-white to-teal-50 rounded-2xl shadow-lg p-8 mb-6 bounce-in">
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-6 bounce-in">
          <span className="text-4xl pulse-emoji">🏝️</span>
        </div>
        <h2 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-3">어디서 만날까요? 🌿</h2>
        <p className="text-lg text-emerald-700 font-medium">서울의 자연스럽고 아름다운 장소들 중에서 선택해주세요!</p>
      </div>

      {/* Map Placeholder */}
      <div className="mb-8">
        <div className="h-80 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-xl relative overflow-hidden border-2 border-dashed border-emerald-300" 
             style={{ backgroundImage: "url('https://images.unsplash.com/photo-1545558014-8692077e9b5c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=600')" }}>
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-teal-500/20"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg bounce-in">
              <p className="text-emerald-700 text-center font-medium">
                <span className="text-3xl pulse-emoji mb-3 block">🗺️</span>
                Google Maps 연동 예정<br/>
                <span className="text-sm text-emerald-600">자연과 함께하는 서울 지도로 만나요! 🌿</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Location Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {locations.map((location, index) => {
          const IconComponent = location.icon;
          const isSelected = selectedLocation === location.id;
          return (
            <Card 
              key={location.id}
              className={`cursor-pointer fun-card relative overflow-hidden border-2 ${
                isSelected 
                  ? `border-transparent bg-gradient-to-br ${location.color} text-white shadow-2xl selected` 
                  : `border-gray-200 ${location.bgColor} hover:border-gray-300`
              }`}
              onClick={() => onLocationSelect(location.id)}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6 relative">
                {isSelected && (
                  <div className="absolute top-2 right-2">
                    <span className="text-2xl pulse-emoji">✨</span>
                  </div>
                )}
                <div className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
                    isSelected ? 'bg-white/20' : 'bg-white'
                  }`}>
                    <span className="text-3xl pulse-emoji">{location.emoji}</span>
                  </div>
                  <h3 className={`text-xl font-bold mb-2 ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                    {location.name}
                  </h3>
                  <p className={`text-sm ${isSelected ? 'text-white/90' : 'text-gray-600'}`}>
                    {location.description}
                  </p>
                </div>
                {isSelected && (
                  <div className="absolute bottom-2 right-2">
                    <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                      <span className="text-green-500 text-lg">✓</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="text-center">
        <Button 
          onClick={onNext}
          disabled={!selectedLocation}
          className={`px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300 ${
            selectedLocation 
              ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 shadow-lg hover:shadow-xl transform hover:scale-105' 
              : 'bg-gray-300 cursor-not-allowed'
          }`}
        >
          {selectedLocation ? '멋져요! 다음으로 🌿' : '🏝️ 장소를 선택해주세요'} 
          <ArrowRight className="ml-2" size={20} />
        </Button>
      </div>
    </div>
  );
}
