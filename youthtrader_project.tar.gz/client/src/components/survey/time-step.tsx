import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Clock, Sun, Moon, Check, Info } from "lucide-react";

interface TimeStepProps {
  selectedTimes: { time: string; priority: number }[];
  onTimeToggle: (time: string) => void;
  onSubmit: () => void;
  onPrevious: () => void;
}

const timeOptions = [
  { id: "17:00", name: "17:00", description: "오후 5시", icon: Sun, emoji: "🌅", color: "from-amber-400 to-orange-500", bgColor: "bg-amber-50" },
  { id: "18:00", name: "18:00", description: "오후 6시", icon: Sun, emoji: "🌇", color: "from-emerald-400 to-teal-500", bgColor: "bg-emerald-50" },
  { id: "19:00", name: "19:00", description: "오후 7시", icon: Moon, emoji: "🌆", color: "from-teal-400 to-cyan-500", bgColor: "bg-teal-50" },
  { id: "20:00", name: "20:00", description: "오후 8시", icon: Moon, emoji: "🌃", color: "from-cyan-400 to-blue-500", bgColor: "bg-cyan-50" },
];

export function TimeStep({ selectedTimes, onTimeToggle, onSubmit, onPrevious }: TimeStepProps) {
  const getTimePriority = (timeId: string) => {
    const timePreference = selectedTimes.find(t => t.time === timeId);
    return timePreference ? timePreference.priority : 0;
  };

  return (
    <div className="bg-gradient-to-br from-emerald-50 via-white to-teal-50 rounded-2xl shadow-lg p-8 mb-6 bounce-in">
      <div className="text-center mb-8">
        <div className="w-20 h-20 bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-6 bounce-in">
          <span className="text-4xl pulse-emoji">🕐</span>
        </div>
        <h2 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-3">모임 시간은 언제가 좋아요? 🕐</h2>
        <p className="text-lg text-emerald-700 font-medium">편안한 시간대를 우선순위대로 선택해주세요! 🌿</p>
      </div>

      <div className="mb-8">
        <h3 className="text-xl font-bold text-emerald-700 mb-6 text-center">🗓️ 7월 22일 (화요일) 힐링 타임</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {timeOptions.map((time, index) => {
            const priority = getTimePriority(time.id);
            const isSelected = priority > 0;
            
            return (
              <Card 
                key={time.id}
                className={`cursor-pointer fun-card relative overflow-hidden border-2 ${
                  isSelected 
                    ? `border-emerald-200 bg-gradient-to-br ${time.color} text-white shadow-2xl selected` 
                    : `border-emerald-200/50 bg-white/90 hover:border-emerald-300 hover:bg-white`
                }`}
                onClick={() => onTimeToggle(time.id)}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-6 relative">
                  {isSelected && (
                    <div className="absolute top-2 right-2">
                      <span className="text-2xl pulse-emoji">✨</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                        isSelected ? 'bg-white/20' : 'bg-white'
                      }`}>
                        <span className="text-3xl pulse-emoji">{time.emoji}</span>
                      </div>
                      <div>
                        <h4 className={`text-xl font-bold ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                          {time.name}
                        </h4>
                        <p className={`text-sm ${isSelected ? 'text-white/90' : 'text-gray-600'}`}>
                          {time.description}
                        </p>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="bg-white text-green-600 px-3 py-1 rounded-full text-sm font-bold">
                        {priority}순위
                      </div>
                    )}
                  </div>
                  {isSelected && (
                    <div className="absolute bottom-2 right-2">
                      <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                        <span className="text-green-500 text-lg">✓</span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <div className="bg-emerald-50/80 backdrop-blur-sm border border-emerald-200/50 rounded-xl p-6 mb-8">
        <div className="flex items-start space-x-4">
          <span className="text-2xl">🌿</span>
          <div>
            <h4 className="font-bold text-emerald-700 mb-2">선택 방법</h4>
            <p className="text-sm text-emerald-600">시간대를 클릭하면 우선순위가 자동으로 설정돼요. 다시 클릭하면 선택이 취소됩니다!</p>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center">
        <Button 
          onClick={onPrevious}
          variant="outline"
          className="px-6 py-3 bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-800"
        >
          <ArrowLeft className="mr-2" size={16} /> 이전
        </Button>
        
        <div className="text-center">
          <p className="text-emerald-600 text-sm mb-2">
            {selectedTimes.length > 0 ? `${selectedTimes.length}개 시간 선택됨` : '시간을 선택해주세요'}
          </p>
        </div>

        <Button 
          onClick={onSubmit}
          disabled={selectedTimes.length === 0}
          className={`px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300 ${
            selectedTimes.length > 0
              ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white hover:from-emerald-600 hover:to-teal-600 shadow-lg hover:shadow-xl transform hover:scale-105' 
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          {selectedTimes.length > 0 ? '완료! 설문 제출 🌿' : '⏰ 시간을 골라주세요'}
          <Check className="ml-2" size={20} />
        </Button>
      </div>
    </div>
  );
}
