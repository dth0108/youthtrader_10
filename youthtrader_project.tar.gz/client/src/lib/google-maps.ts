// Google Maps integration utilities
export interface GoogleMapsConfig {
  apiKey: string;
  libraries: string[];
}

export const initializeGoogleMaps = async (config: GoogleMapsConfig) => {
  if (typeof window === 'undefined') return null;
  
  try {
    // Load Google Maps script
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${config.apiKey}&libraries=${config.libraries.join(',')}`;
    script.async = true;
    script.defer = true;
    
    return new Promise((resolve, reject) => {
      script.onload = () => resolve(window.google);
      script.onerror = reject;
      document.head.appendChild(script);
    });
  } catch (error) {
    console.error('Failed to load Google Maps:', error);
    return null;
  }
};

export const searchNearbyRestaurants = async (location: string, foodType: string) => {
  // This would integrate with Google Places API
  // For now, we'll use our backend data
  try {
    const response = await fetch(`/api/restaurants/${location}/${foodType}`);
    if (!response.ok) throw new Error('Failed to fetch restaurants');
    return await response.json();
  } catch (error) {
    console.error('Error fetching restaurants:', error);
    return [];
  }
};

export const getLocationCoordinates = (locationId: string) => {
  // Seoul location coordinates
  const coordinates: Record<string, { lat: number; lng: number }> = {
    gangnam: { lat: 37.5173, lng: 127.0473 },
    hongdae: { lat: 37.5566, lng: 126.9240 },
    jongno: { lat: 37.5735, lng: 126.9788 },
    myeongdong: { lat: 37.5636, lng: 126.9825 },
    hangang: { lat: 37.5219, lng: 126.9364 },
    sinchon: { lat: 37.5583, lng: 126.9364 },
  };

  return coordinates[locationId] || { lat: 37.5665, lng: 126.9780 }; // Default to Seoul center
};
